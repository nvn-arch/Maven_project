package users;

import org.testng.annotations.Test;

import testbase.BaseClass;

public class CreateUser extends BaseClass {
	
	@Test
	public void testCreateUser() {
		System.out.println("Create User");
	}
}
