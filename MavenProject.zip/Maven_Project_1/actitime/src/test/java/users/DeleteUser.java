package users;

import org.testng.annotations.Test;

import testbase.BaseClass;

public class DeleteUser extends BaseClass{
	
	@Test
	public void testDeleteUser() {
		System.out.println("Delete User");
	}
}
