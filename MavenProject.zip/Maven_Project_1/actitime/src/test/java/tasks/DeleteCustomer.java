package tasks;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import testbase.BaseClass;

public class DeleteCustomer extends BaseClass {
	@Test
	public void testDeleteCustomer() {
		tp.clickOnTasks(driver);
		String custName=xlib.getExcelData("DeleteCustomer", 1, 0);
		driver.findElement(By.xpath("(//input[@placeholder='Start typing name ...'])[1]")).sendKeys(custName);
		
		WebElement editButton=driver.findElement(By.xpath("//span[text()='"+custName+"']/../../..(//div[@class='editButton'])[15]")); //(//div[@class='editButton'])[15]
		Actions act= new Actions(driver);
		act.moveToElement(editButton).perform();
		//WebElement actionsButton=driver.findElement(By.xpath("(//div[text()='ACTIONS'])[1]"));
		//act.moveToElement(actionsButton).click().perform();
		
		//driver.findElement(By.xpath("(//span[text()='"+custName+"'])[1]/../../..//div[@class='editButton']")).click();
		driver.findElement(By.xpath("(//div[text()='ACTIONS'])[1]")).click();
		driver.findElement(By.xpath("(//div[text()='Delete'])[2]")).click();
		driver.findElement(By.xpath("//span[text()='Delete permanently']")).click();
	}
}